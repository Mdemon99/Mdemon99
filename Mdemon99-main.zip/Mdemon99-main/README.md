- 👋 Hi, I’m @Mdemon99
- 👀 I’m interested in ...
- 🌱 I’m currently learning ...
- 💞️ I’m looking to collaborate on ...
- 📫 How to reach me ...

<!---
Mdemon99/Mdemon99 is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.



* Crack ID Grub
* Crack ID Teman
* Crack ID Publik
* Crack ID Dari Link Post
* Crack ID Dari Pencarian Nama
```
### Install
```bash
$ pkg update && pkg upgrade
$ pkg install python && pkg install python2
$ pkg install git
$ git clone https://github.com/Mdemon99/Mdemon99.git
```
### 
```bash
$ls
$ cd mdemon99
$ bash setup.sh
$ python mdemon99.py
```
